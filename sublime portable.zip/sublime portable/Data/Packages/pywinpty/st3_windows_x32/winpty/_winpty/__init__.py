# -*- coding: utf-8 -*-
"""Winpty headers."""
