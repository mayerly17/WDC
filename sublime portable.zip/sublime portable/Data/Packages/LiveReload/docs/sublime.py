# -*- coding: utf-8 -*-
import os

def packages_path():
    return os.path.abspath('../../')

def error_message(string):
  pass

platform = "build"